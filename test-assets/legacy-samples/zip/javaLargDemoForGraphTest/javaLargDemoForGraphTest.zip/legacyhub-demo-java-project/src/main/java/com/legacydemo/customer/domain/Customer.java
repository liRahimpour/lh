package com.legacydemo.customer.domain;

public record Customer(
        long id,
        String firstName,
        String lastName,
        String email,
        CustomerStatus status
) {
    public static Customer newCustomer(String firstName, String lastName, String email) {
        return new Customer(0L, firstName, lastName, email, CustomerStatus.ACTIVE);
    }

    public Customer withStatus(CustomerStatus newStatus) {
        return new Customer(id, firstName, lastName, email, newStatus);
    }
}
