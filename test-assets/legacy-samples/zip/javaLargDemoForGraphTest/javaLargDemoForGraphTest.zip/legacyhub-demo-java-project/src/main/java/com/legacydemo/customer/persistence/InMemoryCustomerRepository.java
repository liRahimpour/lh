package com.legacydemo.customer.persistence;

import com.legacydemo.customer.domain.Customer;
import com.legacydemo.customer.domain.CustomerStatus;

import java.util.ArrayList;
import java.util.List;

public class InMemoryCustomerRepository implements CustomerRepository {

    private final List<Customer> customers = new ArrayList<>();
    private long nextId = 1L;

    public Customer save(Customer customer) {
        Customer persistedCustomer = new Customer(
                nextId++,
                customer.firstName(),
                customer.lastName(),
                customer.email(),
                customer.status()
        );

        customers.add(persistedCustomer);
        return persistedCustomer;
    }

    public Customer findById(long customerId) {
        return customers.stream()
                .filter(customer -> customer.id() == customerId)
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("Customer not found: " + customerId));
    }

    public List<Customer> findByStatus(CustomerStatus status) {
        return customers.stream()
                .filter(customer -> customer.status() == status)
                .toList();
    }
}
