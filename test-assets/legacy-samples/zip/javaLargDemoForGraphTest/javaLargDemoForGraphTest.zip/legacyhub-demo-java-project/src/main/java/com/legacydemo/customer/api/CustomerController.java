package com.legacydemo.customer.api;

import com.legacydemo.customer.application.CustomerService;
import com.legacydemo.customer.domain.Customer;
import com.legacydemo.customer.domain.CustomerStatus;

public class CustomerController {

    private final CustomerService customerService;

    public CustomerController(CustomerService customerService) {
        this.customerService = customerService;
    }

    public CustomerResponse register(RegisterCustomerRequest request) {
        Customer customer = customerService.register(
                request.firstName(),
                request.lastName(),
                request.email()
        );

        return CustomerResponse.from(customer);
    }

    public CustomerResponse findById(long customerId) {
        return CustomerResponse.from(customerService.findById(customerId));
    }

    public void deactivate(long customerId) {
        customerService.changeStatus(customerId, CustomerStatus.INACTIVE);
    }
}
