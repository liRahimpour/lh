package com.legacydemo.customer.persistence;

public class CustomerTableGateway {

    private final String tableName = "customer";

    public String insertStatement() {
        return "INSERT INTO " + tableName + " (first_name, last_name, email, status) VALUES (?, ?, ?, ?)";
    }

    public String selectActiveStatement() {
        return "SELECT * FROM " + tableName + " WHERE status = 'ACTIVE'";
    }

    public String updateStatusStatement() {
        return "UPDATE " + tableName + " SET status = ? WHERE id = ?";
    }
}
