package com.legacydemo.customer.api;

import com.legacydemo.customer.domain.Customer;

public record CustomerResponse(
        long id,
        String displayName,
        String email,
        String status
) {
    public static CustomerResponse from(Customer customer) {
        return new CustomerResponse(
                customer.id(),
                customer.firstName() + " " + customer.lastName(),
                customer.email(),
                customer.status().name()
        );
    }
}
