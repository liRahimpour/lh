package com.legacydemo.customer.persistence;

import com.legacydemo.customer.domain.Customer;
import com.legacydemo.customer.domain.CustomerStatus;

import java.util.List;

public interface CustomerRepository {

    Customer save(Customer customer);

    Customer findById(long customerId);

    List<Customer> findByStatus(CustomerStatus status);
}
