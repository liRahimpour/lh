package com.legacydemo.customer.api;

public record RegisterCustomerRequest(
        String firstName,
        String lastName,
        String email
) {
}
