package com.legacydemo.customer.application;

public class CustomerValidator {

    private static final int MINIMUM_EMAIL_LENGTH = 5;

    public void validateEmail(String email) {
        if (email == null || email.length() < MINIMUM_EMAIL_LENGTH || !email.contains("@")) {
            throw new IllegalArgumentException("A valid email address is required");
        }
    }

    public boolean isCorporateEmail(String email) {
        return email != null && email.endsWith("@example.com");
    }
}
