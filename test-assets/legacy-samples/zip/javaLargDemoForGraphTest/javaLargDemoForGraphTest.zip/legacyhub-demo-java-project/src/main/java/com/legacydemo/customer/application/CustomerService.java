package com.legacydemo.customer.application;

import com.legacydemo.customer.domain.Customer;
import com.legacydemo.customer.domain.CustomerStatus;
import com.legacydemo.customer.persistence.CustomerRepository;

import java.util.List;

public class CustomerService {

    private final CustomerRepository customerRepository;
    private final CustomerValidator customerValidator;
    private final CustomerEventPublisher eventPublisher;

    public CustomerService(
            CustomerRepository customerRepository,
            CustomerValidator customerValidator,
            CustomerEventPublisher eventPublisher
    ) {
        this.customerRepository = customerRepository;
        this.customerValidator = customerValidator;
        this.eventPublisher = eventPublisher;
    }

    public Customer register(String firstName, String lastName, String email) {
        customerValidator.validateEmail(email);

        Customer customer = Customer.newCustomer(firstName, lastName, email);
        Customer savedCustomer = customerRepository.save(customer);

        eventPublisher.publishCustomerRegistered(savedCustomer);
        return savedCustomer;
    }

    public Customer findById(long customerId) {
        return customerRepository.findById(customerId);
    }

    public List<Customer> findActiveCustomers() {
        return customerRepository.findByStatus(CustomerStatus.ACTIVE);
    }

    public Customer changeStatus(long customerId, CustomerStatus status) {
        Customer customer = findById(customerId);
        Customer updatedCustomer = customer.withStatus(status);

        return customerRepository.save(updatedCustomer);
    }
}
