package com.legacydemo.config;

import com.legacydemo.customer.application.CustomerEventPublisher;
import com.legacydemo.customer.application.CustomerService;
import com.legacydemo.customer.application.CustomerValidator;
import com.legacydemo.customer.persistence.CustomerRepository;
import com.legacydemo.customer.persistence.InMemoryCustomerRepository;

public class LegacyDemoApplication {

    private final CustomerRepository customerRepository = new InMemoryCustomerRepository();
    private final CustomerValidator customerValidator = new CustomerValidator();

    public CustomerService createCustomerService(CustomerEventPublisher eventPublisher) {
        return new CustomerService(customerRepository, customerValidator, eventPublisher);
    }

    public String applicationName() {
        return "LegacyHub Demo Customer Application";
    }
}
