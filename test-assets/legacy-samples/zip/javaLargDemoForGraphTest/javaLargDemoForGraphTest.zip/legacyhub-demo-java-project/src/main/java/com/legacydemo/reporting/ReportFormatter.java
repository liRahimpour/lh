package com.legacydemo.reporting;

import com.legacydemo.customer.domain.Customer;

import java.util.List;

public class ReportFormatter {

    public String format(List<Customer> customers) {
        StringBuilder report = new StringBuilder("Active customers:\n");

        for (Customer customer : customers) {
            report.append(customer.id())
                    .append(": ")
                    .append(customer.firstName())
                    .append(" ")
                    .append(customer.lastName())
                    .append("\n");
        }

        return report.toString();
    }
}
