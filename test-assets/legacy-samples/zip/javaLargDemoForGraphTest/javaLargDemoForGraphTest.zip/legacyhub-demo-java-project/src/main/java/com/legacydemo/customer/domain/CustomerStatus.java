package com.legacydemo.customer.domain;

public enum CustomerStatus {
    ACTIVE,
    INACTIVE,
    SUSPENDED
}
