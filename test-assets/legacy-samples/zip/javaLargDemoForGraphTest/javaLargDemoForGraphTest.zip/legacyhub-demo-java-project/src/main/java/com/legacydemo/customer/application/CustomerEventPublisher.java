package com.legacydemo.customer.application;

import com.legacydemo.customer.domain.Customer;

public interface CustomerEventPublisher {

    void publishCustomerRegistered(Customer customer);

    void publishCustomerDeactivated(Customer customer);
}
