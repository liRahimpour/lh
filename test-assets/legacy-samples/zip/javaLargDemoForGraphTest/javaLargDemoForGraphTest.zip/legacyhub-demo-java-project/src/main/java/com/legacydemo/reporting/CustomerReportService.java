package com.legacydemo.reporting;

import com.legacydemo.customer.application.CustomerService;
import com.legacydemo.customer.domain.Customer;

import java.util.List;

public class CustomerReportService {

    private final CustomerService customerService;
    private final ReportFormatter reportFormatter;

    public CustomerReportService(CustomerService customerService, ReportFormatter reportFormatter) {
        this.customerService = customerService;
        this.reportFormatter = reportFormatter;
    }

    public String createActiveCustomerReport() {
        List<Customer> customers = customerService.findActiveCustomers();
        return reportFormatter.format(customers);
    }

    public int activeCustomerCount() {
        return customerService.findActiveCustomers().size();
    }
}
