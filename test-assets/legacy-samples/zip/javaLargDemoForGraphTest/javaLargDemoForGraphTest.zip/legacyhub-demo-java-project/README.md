# LegacyHub Demo Java Project

Dieses kleine Projekt ist bewusst für die aktuelle LegacyHub-Pipeline gebaut:

1. ZIP hochladen
2. Symbolanalyse ausführen
3. Relationanalyse ausführen
4. Graph-Sync ausführen
5. Graph Explorer Endpoints demonstrieren

## Enthaltene Fälle

- package / fully qualified names
- interface
- enum
- record
- mehrere Klassen
- Felder
- Methoden
- Konstruktoren
- Service → Repository → Mapper → SQL-artige Datenzugriffsklasse
- Controller als Einstiegspunkt
- mehrere Dateien in unterschiedlichen Packages

## Wichtige Erwartung für den aktuellen Stand

Der aktuelle Relation Analyzer erzeugt strukturelle Relationen innerhalb einer Datei:

- CLASS -> HAS_METHOD -> METHOD
- CLASS -> HAS_FIELD -> FIELD

Er erkennt aktuell noch **keine echten CALLS-, USES- oder DEPENDS_ON-Relationen**
zwischen Dateien. Deshalb zeigen `dependencies?depth=2` und `impact?depth=2`
noch keine echte fachliche Kette Controller -> Service -> Repository.

Dieses Projekt ist aber bereits vorbereitet, damit wir genau diese Relation-Analyzer
als nächsten fachlichen Ausbau testen können.

## Empfehlenswerte Demo-Reihenfolge

1. `CustomerController` in Neighbors öffnen:
   - erwartete Methoden und Felder
2. `CustomerService` in Neighbors öffnen:
   - erwartete Methoden und Felder
3. Graph Overview zeigen:
   - Symbolanzahl und Relationstypen
4. Nach späterem CALLS/USES-Analyzer:
   - `CustomerController` Dependencies mit depth=3
   - `CustomerTableGateway` Impact mit depth=3
